# CrewAI Open Source Analysis

Generated: 2025-09-24

Summary
-------
CrewAI is an opinionated multi-agent orchestration platform focused on making it simple to "create a crew" of agents with Roles and Goals, kick off tasks, and monitor progress. The public site points to the core open-source framework (https://github.com/crewAIInc/crewAI) and a number of examples and templates. CrewAI emphasizes templates/playbooks, monitoring, and a UX for non-engineers to define multi-step agent workflows.

Key Features Observed
---------------------
- Crew definition: Role + Goal model for composing agents into a team.
- Templates and examples: ready-made playbooks for common tasks (research, automation, data extraction).
- Kickoff + monitoring: single-click kickoff flows and real-time progress dashboards.
- Community & docs-first approach: many examples, Youtube tutorials, and an interactive "chat with docs" helper.

Why CrewAI matters for SomaGent UIX
----------------------------------
CrewAI codifies an approachable UX layer for multi-agent orchestration. SomaGent's UIX is interface-agnostic and provenance-first; CrewAI adds a mature mental model (crew/role/goal) and strong product patterns (templates, monitoring, step-in controls) that accelerate user onboarding and operational control.

Recommendations (adopt/adapt)
----------------------------
1. Crew Builder UI (Adopt): Implement a lightweight crew builder in `AgentBuilder` that exposes Role and Goal fields, plus task delegation policies. Surface deterministic provenance metadata for crew-created messages.
2. Templates & Playbooks (Adopt): Add a `Templates` section in the Marketplace and a one-click "start crew from template" flow tied to tenant-safe examples.
3. Live Monitoring Dashboard (Adapt): Create an Ops view showing running crews, per-agent progress, token usage, and a "step in" button that pauses an agent and lets a human take over.
4. Kickoff & Replay (Adapt): Store crew run inputs so users can replay or fork runs; preserve request_hash and provenance for each replay.
5. Embedded Docs Chat (Adopt): Provide a local "chat with docs" sidecar in the AdminDashboard and AgentBuilder to help users interactively discover templates and best practices.
6. Examples & Onboarding (Adopt): Ship a `crewAI-examples`-like folder of starter templates under `docs/` and as optional seed data in tenant onboarding.

Integration Mapping to SomaGent Components
-----------------------------------------
- Crew Builder -> `AgentBuilder` page and `AgentTree` organism
- Templates -> `MarketplaceCard` + `AgentBuilder` import flow
- Monitoring -> new `OpsDashboard` page + realtime metrics stream from `orchestrator` service
- Replay/Fork -> tie into `model-proxy` to re-invoke with same `request_hash` semantics
- Docs Chat -> small chat widget powered by a RAG instance over `docs/` content

Low-risk First Steps
--------------------
1. Add Templates folder and 3 starter templates (research, summarization, and data-extraction) to `docs/templates/` and expose them via `MarketplaceCard`.
2. Add a minimal Crew Builder form to `AgentBuilder` that persists definitions to the `orchestrator` service (POST `/v1/agents` with role/goal fields).
3. Add an OpsDashboard MVP that lists running crews (calls GET `/v1/orchestrator/crews`) and shows a "view trace" link into the existing `/v1/agents/{agent_id}/trace` API.

Risks & Considerations
----------------------
- UX complexity: Crew concepts add cognitive load. Solve via templates and guided onboarding.
- Security: templates may contain provider or tool settings; ensure secrets never travel in templates and that templates are tenant-scoped.
- Cost: multi-agent runs can be expensive; surface token/cost estimates before kickoff.

Links
-----
- CrewAI repo: https://github.com/crewAIInc/crewAI
- CrewAI examples: https://github.com/crewAIInc/crewAI-examples
- CrewAI docs: https://docs.crewai.com/

Appendix: Actionable TODOs
-------------------------
- Create `docs/templates/crew-research.yaml`, `crew-summary.yaml`, `crew-extract.yaml` starter templates. (low-risk)
- Implement `AgentBuilder` form additions for Role/Goal (UI patch). (low-risk)
- Add `OpsDashboard` skeleton and wire to `orchestrator` GET endpoint. (spike)

---

End of CrewAI analysis.
