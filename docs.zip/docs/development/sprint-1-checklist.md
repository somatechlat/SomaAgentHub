```markdown
# Sprint 1 Checklist — Execution & Policy

This checklist tracks the smallest, verifiable tasks for Sprint 1. Mark items as you complete them and link PRs/issues.

- [ ] Create `services/constitution-service` FastAPI skeleton (README, requirements, app).
- [ ] Implement `/v1/constitution` GET endpoint that returns current constitution hash and metadata.
- [ ] Add Redis caching for constitution hash (configurable via env `REDIS_URL`).
- [ ] Add unit tests for constitution fetch + cache semantics.
- [ ] Implement `services/policy-engine` basic evaluator skeleton with `/v1/evaluate` POST endpoint.
- [ ] Add `services/slm-service` worker skeleton (simple in-memory queue + health endpoint).
- [ ] Add `services/settings-service` CRUD endpoints for model profiles (in-memory or sqlite for sprint).
- [ ] Wire basic CI checks for linting and unit tests in a GitHub Actions workflow (or local Makefile tasks).

Local run tips
```bash
# constitution-service (local dev)
cd services/constitution-service
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8300

# Quick Redis for local caching (if you don't have Redis installed):
docker run --rm -p 6379:6379 redis:7
```

Acceptance criteria
- `GET /v1/constitution` returns 200 with JSON {"hash": "<sha256>", "version": "v1", "fetched_at": "<iso>"}
- Repeated calls hit cache (verify via logs or Redis key existence)

``` 
