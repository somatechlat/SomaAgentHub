# LIBRECHATResearch

This document captures the researched roadmap and integration plan for adapting LibreChat to fit SomaGent's requirements. It is derived from the analysis performed on Sep 24, 2025.

## Executive summary
- Goal: Use LibreChat as a fast path to a production-ready Agent UI while ensuring LibreChat is modified to meet SomaGent requirements (tenanting, provenance, signed billing, server-side adapters, theme tokens, RBAC).
- Strategy: Two-stage approach
  1. Timeboxed Spike — validate feasibility quickly (iframe or microfrontend embed + SSO).
  2. Prototype & Harden — build server adapters (model proxy, memory gateway mapping, billing hooks), enforce security & tenancy, then extract shared UI components into a `@somagent/uix` package for long-term ownership.

## Phase 0 — Spike (3–7 days)
Primary objective: Prove LibreChat can authenticate with SomaGent SSO, call our model adapter, and emit billing events.

Tasks
- 0.1: Run LibreChat locally and inspect architecture and main UI bundles.
  - Deliverable: short README snippet documenting how to run client locally (Docker / npm).
  - Acceptance: team member can start LibreChat locally and load the UI.
- 0.2: Embed LibreChat as an iframe route in `apps/admin-console` for a demo.
  - Deliverable: `apps/admin-console/src/pages/librechat-embed.tsx` (iframe wrapper + theme CSS variables).
  - Acceptance: Admin console can open the embed and display LibreChat; basic theme variables override apply.
- 0.3: Configure OIDC SSO flow for dev:
  - LibreChat login should accept SomaGent dev OIDC token (or accept token via header for the spike).
  - Acceptance: Login from admin console SSO results in an authenticated LibreChat session (dev-only mode).
- 0.4: Add a small proxy stub in `gateway-api/` or `services/librechat-adapter/` which bridges LibreChat’s model calls to a stub that emits billing events to `services/billing-service`.
  - Acceptance: A conversation leads to a billing event written to `services/billing-service` JSONL or endpoint.

Quick commands (run locally for the spike)

```bash
# clone and run the LibreChat client locally (example)
git clone https://github.com/danny-avila/LibreChat.git ~/dev/librechat
cd ~/dev/librechat/client
npm install
npm run dev
```

```bash
# start admin console dev (from repo root)
cd /Users/macbookpro201916i964gb1tb/Documents/GitHub/somaagent/apps/admin-console
npm install
npm run dev
# open http://localhost:5173 and the embed page you add
```

Acceptance for spike: a demo user can open the admin console, open the LibreChat embed, sign in via dev SSO, send a message, and see a billing event recorded in `services/billing-service`.

## Phase 1 — Prototype & Adapter (2–4 weeks)
Primary objectives: stop frontend from making direct provider calls, implement server adapters for models and memory, enforce billing/provenance.

Tasks & deliverables
1. Model Adapter Service
   - Create `services/model-proxy/` (FastAPI) or extend `gateway-api/`.
   - Endpoints:
     - POST /v1/models/invoke — accepts {tenant_id,user_id,model,conversation_id,prompt,stream}
     - Streams SSE/WebSocket back to the client (map to LibreChat streaming contract).
   - Responsibilities:
     - Translate/forward to provider backends (OpenAI, Anthropic, etc.) from server-side.
     - Compute deterministic `request_hash`, sign if needed (use existing `somagent_somabrain` helpers).
     - Emit billing event to `services/billing-service` with token counts, request_hash, provenance.
   - Acceptance:
     - Frontend cannot reach external provider directly (CORS blocked); model calls go through /v1/models/invoke and a billing event appears matching token totals.

2. Memory Gateway / RAG integration
   - Map LibreChat RAG calls to `memory-gateway` endpoints:
     - POST /v1/memory/search {tenant_id,query,top_k} → returns results with metadata.provenance fields.
   - Acceptance:
     - RAG snippets returned in conversation display provenance links to memory entries (conversation_id + snippet_id).

3. Billing/Audit
   - Ensure the adapter posts to `services/billing-service` (same shape as earlier recommended).
   - Implement server-side validation/signing of billing events where possible.
   - Acceptance:
     - Billing events include request_hash and are verifiable by the billing ingest service.

4. Theming & UI tokens
   - Add CSS variables shim for SomaGent tokens in the embed or adapt LibreChat theme files to read tokens from tenant settings.
   - Acceptance:
     - Switching tenant theme in admin console updates LibreChat UI colors and fonts (basic).

5. Auth & Tenancy
   - Integrate OIDC SSO: admin console performs SSO, server sets Authorization header for LibreChat embed/microfrontend or proxy.
   - Ensure backend validates token and enforces tenant_scoping.
   - Acceptance:
     - API calls to model-proxy require bearer tokens; cross-tenant calls rejected.

Suggested file paths to add/modify
- `apps/admin-console/src/pages/librechat-embed.tsx` — iframe or microfrontend wrapper.
- `services/model-proxy/` — new FastAPI service.
- `services/librechat-adapter/README.md` — run instructions.
- `services/billing-service/` — ensure endpoints accept events from model-proxy.
- `libs/uix/` (or `packages/uix/`) — later extraction of components.
- `infra/` or `docker-compose.dev.yml` — local compose entries for model-proxy for dev.

Estimated effort: 2–4 weeks (small team: 1–2 engineers) to reach a robust prototype with tenanting and billing.

## Phase 2 — Extraction & Consolidation (4–8+ weeks)
Primary objectives: extract core UI components into `@somagent/uix`, full security hardening, telemetry, e2e tests, and controlled rollout.

Tasks
- Extract conversation timeline and composer components into `libs/uix/`:
  - Message bubble, streaming partials, composer, voice controls, agent marketplace card.
  - Add Storybook + accessibility tests.
  - Acceptance: Components render inside `apps/admin-console` and LibreChat-derived UI without breaking functionality.
- Replace embedded iframe with native components in `apps/admin-console` (or adopt MFEs).
  - Acceptance: Conversation UX is identical or better, theme tokens first-class.
- Observability & telemetry
  - Add OpenTelemetry traces across frontend/backends (include conversation_id, request_hash).
  - Acceptance: traces link frontend events to model-proxy and billing events.
- Security & Compliance
  - RBAC enforcement in APIs, tenant-scoped DB access, server review, penetration testing.
  - Acceptance: Security checklist cleared; no provider keys in the browser.

Estimated effort: 4–8+ weeks.

## Testing, CI, and Acceptance tests
- Add Playwright e2e suite in `apps/admin-console/tests/e2e/`:
  - Tests: login, start convo, RAG shows provenance, billing event recorded, notification shown on budget alert.
- Unit tests:
  - adapter tests for token counting and request_hash generation (reuse `tests/test_somabrain_client.py` patterns).
- CI:
  - Add GitHub Actions workflow `.github/workflows/e2e.yml`:
    - Steps: install, build admin-console, run model-proxy in a container, start billing-service, run Playwright tests.
- Acceptance criteria example:
  - E2E: A user logs in, starts a conversation, receives a streaming reply, memory snippet provenance properly links, and a billing event with matching token counts is recorded.

## Security & operational controls (must-have)
- No direct provider calls from browser. All provider interactions through server-side model-proxy.
- Billing events must contain request_hash and be signed when possible. Billing-service will reconcile server-observed counts with posted events.
- Tenant ID must be enforced on each API call; tokens validated server-side.
- Secrets stored in Vault / secrets manager; UI only references Vault IDs (no raw keys).
- CSP and postMessage security if using iframe composition.

## Risks and mitigations (short)
- Risk: Token counting mismatch → Discrepancies in billing.
  - Mitigation: Server-side counting and signed events; provider receipts matched to events.
- Risk: UX divergence or slow performance (iframe).
  - Mitigation: Timebox spike; if poor UX, pivot to component extraction (Phase 2).
- Risk: Large engineering effort to extract components.
  - Mitigation: Prioritize the few highest-value components (timeline, composer, marketplace) and extract incrementally.

## Timeline summary (rough)
- Spike (proof-of-concept): 3–7 days
- Prototype & adapter (tenanting, billing, proxy): 2–4 weeks
- Extraction & consolidation (UI library, telemetry, hardening): 4–8+ weeks
Total to production-grade: ~8–16 weeks depending on scope and team size

## Minimal prioritized next actions (pick one)
1. Quick spike: I’ll add an iframe demo route in `apps/admin-console` and a short README for how to run LibreChat locally and demo SSO. (Estimate: 1–2 days)
2. Model adapter prototype: I’ll scaffold `services/model-proxy` (FastAPI) that streams to the frontend and posts billing events to `services/billing-service`. (Estimate: 1–2 weeks)
3. Test plan and CI: I’ll draft Playwright e2e tests and a GitHub Actions workflow to run the integration tests. (Estimate: 1 week)

Tell me which to start and I’ll:
- update the todo list (mark chosen task in-progress),
- create the files and scaffolding, and
- run the minimal tests locally where applicable and report back with results and commands to run them.

Which of the three should I do now?
