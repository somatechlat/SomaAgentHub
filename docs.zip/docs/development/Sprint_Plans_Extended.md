```markdown
# SomaGent Extended Sprint Plans (Sprints 1–12)

This document expands the sprint milestones into detailed, actionable sprint plans with deliverables, acceptance criteria, suggested owners, and immediate next actions. Use these plans to assign work, create issues, and run sprint ceremonies.

Guidelines:
- Sprint length: 2 weeks (adjustable).
- Definition of Done: code merged to `develop`/`main` per repo policy, CI green (lint/tests), docs updated, and runbook entries created if security/ops changes apply.
- Owners: assign a primary owner and 1–2 reviewers for each deliverable.

Sprint 1 — Execution & Policy (2 weeks)
- Goals:
  - Implement Constitution Service MVP (fetch/verify/save constitution hash).
  - Policy Engine basic evaluator with `/v1/evaluate` API.
  - Start Async SLM queue skeleton.
  - Identity/settings CRUD bootstrapping.
- Deliverables:
  - `services/constitution-service` FastAPI app with endpoints and Redis cache integration.
  - `services/policy-engine` simple rules evaluator and CI tests.
  - `services/slm-service` queue consumer skeleton (async worker) and health endpoint.
  - `services/settings-service` CRUD for model profiles (stubbed DB).
- Acceptance criteria:
  - Constitution endpoint returns signed hash and cached value in Redis.
  - Policy evaluator accepts JSON action and returns score + verdict within 50ms.
  - SLM consumer can accept a job from an in-memory queue and log a placeholder response.
  - CRUD endpoints pass contract tests (OpenAPI + basic unit tests).
- Suggested owners: backend lead, security engineer (constitution), infra (redis).
- Immediate next tasks:
  - Create issues: `constitution-service: init`, `policy-engine: init`, `slm-service: worker-skeleton`.

Sprint 2 — Benchmarks & Observability (2 weeks)
- Goals:
  - Build benchmark harness and scoring service.
  - Add Prometheus metrics and basic Grafana dashboard skeletons.
  - Notification orchestrator stub (Kafka consumer producing WebSocket notifications).
- Deliverables:
  - `services/benchmark-service` that runs nightly capsules and writes results to Postgres.
  - Prometheus metrics in core services (gateway, orchestrator, slm) with example dashboards.
  - Notification orchestrator service that consumes `notifications.events` and forwards to WebSocket.
- Acceptance criteria:
  - Benchmark service can run a sample benchmark and persist results.
  - Prometheus scrapes sample metrics for gateway and SLM; dashboards display p95 latency.
  - Notification orchestrator correctly relays test Kafka events to a local WebSocket client.
- Owners: observability lead, backend engineer.

Sprint 3 — Advanced Orchestration (2 weeks)
- Goals:
  - MAO prototype (Temporal/Argo integration skeleton).
  - Voice/audio pipeline MVP (ASR adapter stub, TTS stub, feature extraction).
  - Marketplace builder alpha (capsule schema + storage API).
- Deliverables:
  - `services/mao` template import + execute endpoints and a Temporal workflow mapping sample capsule steps to activities.
  - Conversational Experience service: accept WebSocket audio chunks, store log-mel features locally, and produce basic transcripts using a stub adapter.
  - `services/task-capsule-repo` APIs for storing/listing capsules (Postgres-backed).
- Acceptance criteria:
  - MAO can import a capsule manifest and instantiate a basic workflow that logs activity steps.
  - Audio pipeline converts an uploaded WAV to MFCC/log-mel and stores embeddings; transcription endpoint returns placeholder text.
  - Capsules can be created and retrieved via REST API.
- Owners: orchestration lead, audio engineer, backend.

Sprint 4 — Hardening & Launch Readiness (2 weeks)
- Goals:
  - Security hardening basics: JWT handling, gateway context middleware, kill-switch wiring.
  - CI: add ruff/mypy/linting checks, basic unit test coverage gates.
  - Documentation polish for the launch checklist and runbooks.
- Deliverables:
  - Gateway middleware enforcing JWT and `SOMAGENT_GATEWAY_KILL_SWITCH_ENABLED`.
  - CI additions: linters, type checks and basic unit tests in the pipeline.
  - Updated `docs/release/Launch_Readiness_Checklist.md` with owners and dates.
- Acceptance criteria:
  - Gateway rejects requests without valid JWT with 401; kill switch returns 503 when enabled.
  - PRs must pass linter and type checks before merge.
  - Runbooks updated and linked from the README.
- Owners: security lead, CI owner, docs owner.

Sprint 5 — AppSec & Compliance (2 weeks)
- Goals:
  - Implement moderation-before-orchestration filter and strike tracking.
  - Implement basic sandboxing policy for tool-service adapters.
  - Add OTEL traces for key flows.
- Deliverables:
  - Moderation filter middleware + small ML classifier stub or integration.
  - Tool-service adapter runner that starts adapters in constrained containers (configurable limits).
  - Distributed tracing added to gateway and orchestrator (OTEL spans).
- Acceptance criteria:
  - Moderation filter blocks a test message and records a strike in Redis/Postgres.
  - Tool adapter can be started with constrained CPU/memory settings locally.
  - OTEL traces show a full request path through gateway → orchestrator → slm.
- Owners: security engineer, platform engineer.

Sprint 6 — Marketplace & Automation (2 weeks)
- Goals:
  - Capsule publishing flow, attestation hashes, reviewer API.
  - MAO template import + scheduled instantiation.
  - Billing events emitted from tool execution.
- Deliverables:
  - Capsule submission and review APIs in `task-capsule-repo`.
  - `POST /v1/templates/import` endpoint in MAO that converts published capsule to a workflow template.
  - Tool-service emits `billing.events` to analytics after an adapter run.
- Acceptance criteria:
  - Full submission → review → publish flow with stored attestation hashes.
  - MAO can import a approved capsule and schedule a run.
  - Billing events include tenant, adapter, time, estimated tokens and persist to analytics DB.
- Owners: marketplace owner, MAO owner, analytics owner.

Sprint 7 — Analytics & Insights (2 weeks)
- Goals:
  - Persona regression automation and anomaly detection endpoints.
  - Dashboards for capsule runs, billing ledgers and persona regressions.
  - Exports: CSV/JSON endpoints for capsule runs and billing ledgers.
- Deliverables:
  - `services/analytics-service` endpoints: `/v1/persona-regressions/transition`, `/v1/anomalies/scan`, `/v1/exports/*`.
  - Grafana dashboards updated with persona regression indicators.
  - Alerts wired for anomaly detection.
- Acceptance criteria:
  - Analytics service can mark a persona as regressed and produce a transition record.
  - Anomaly endpoint finds injected anomalies in a test dataset and fires an alert.
  - CSV exports produce consistent, timestamped exports for a tenant window.
- Owners: analytics lead, data engineer.

Sprint 8 — Scalability & Multi-region (2 weeks)
- Goals:
  - Multi-region failover rehearsals and DR automation improvements.
  - Residency enforcement tests and per-region config overlays.
  - Autoscaling rules and performance tuning for gateway/SLM.
- Deliverables:
  - `scripts/ops/run_failover_drill.sh` improvements and Temporal workflow to trigger scheduled drills.
  - Helm overlays for two regions and sample Terraform automation (scaffold).
  - HPA/Resource metric tuning and load test results.
- Acceptance criteria:
  - A failover drill completes in test mode and analytics receives `/v1/drills/disaster` summary.
  - Residency policy denies a cross-region tenant request in an integration test.
  - Autoscaling behavior meets p95 latency targets under simulated load.
- Owners: infra lead, SRE.

Sprint 9 — Launch Readiness (2 weeks)
- Goals:
  - Final performance profiling, security audit checklists, release candidate playbook completion.
  - Sample tenant onboarding flow tested end-to-end.
- Deliverables:
  - Release candidate checklist completed and signed off.
  - End-to-end tenant onboarding run (create tenant, install capsule, run capsule, collect analytics).
  - Community/Contributor onboarding docs updated.
- Acceptance criteria:
  - End-to-end test passes without manual intervention in the happy path.
  - Security checklist accepted by auditor or security reviewer.
  - RC built images published with SBOM.
- Owners: release manager, QA.

Sprint 10 — KAMACHIQ Mode Automation (3 weeks)
- Goals:
  - Planner capsule prototype and provisioning harness finalization.
  - Governance overlay capsule and requeue logic in MAO.
  - Auto-retry loop and analytics integration for kamachiq runs.
- Deliverables:
  - `kamachiq_project_planner` capsule template in `task-capsule-repo`.
  - scripts/kamachiq/provision_stack.sh with production-ready dry-run and real adapters wiring.
  - MAO requeue/retry background worker and endpoints (`GET /v1/kamachiq/requeue`, `POST /v1/kamachiq/requeue/{id}/resolve`).
  - Prometheus metrics for KAMACHIQ runs.
- Acceptance criteria:
  - Planner produces a deliverables DAG from a sample roadmap and MAO can instantiate it.
  - Blocked deliverables end up in the requeue store and `/resolve` can re-run policy to proceed or record override.
  - Analytics sees kamachiq run events and governance reports stored.
- Owners: MAO lead, planner engineer, analytics.

Sprint 11 — Capsule Builder & Persona Synthesis (3 weeks)
- Goals:
  - Visual capsule builder UI & persona synthesizer pipeline.
  - Capsule evolution suggestions (feedback loop from run outcomes).
- Deliverables:
  - Admin console capsule builder page (drag-and-drop persona, tools, policies).
  - Persona synthesizer: pipeline that accepts training data and outputs a signed persona shot (stubbed; manual review required).
  - Feedback ingestion: analytics → capsule suggestion queue.
- Acceptance criteria:
  - Non-technical admin can compose a capsule and save it to the repo.
  - Synthesizer outputs a persona shot placeholder and stores an attestation record.
  - Suggestion queue receives run-based suggestions for capsule improvements.
- Owners: UX lead, ML engineer.

Sprint 12 — KAMACHIQ Pilot & Hardening (3 weeks)
- Goals:
  - Run a KAMACHIQ pilot (staging tenant) end-to-end with real adapters in dry-run then small real-run.
  - Final security hardening for KAMACHIQ-sensitive flows (provisioning, billings, tool adapters).
- Deliverables:
  - Pilot report with RAG (risks, actions, gaps) and a remediation backlog.
  - Hardened attestation & adapter policies, final runbooks for provisioning rollbacks.
  - Final metrics dashboard showing KAMACHIQ KPIs.
- Acceptance criteria:
  - Pilot completes with artifacts (repos, boards, docs) created automatically or reported as dry-run.
  - No critical security issues remain for provisioning flows; all medium/low issues triaged.
  - Stakeholder sign-off to proceed to staged tenant launch.
- Owners: product owner, security, MAO.

## How to use this document
- Create issues per deliverable and link them to the sprint. Use owners and acceptance criteria to scope PRs and code reviews.
- Update status on the sprint board and document retrospectives per sprint.
- If priorities change, update sprint contents and keep sprint length and DoD consistent.

## Related operational documents
The project maintains focused operational and planning documents referenced by the sprint plans. New items created during Sprint 0–2 include:

- `docs/development/production_gap_analysis.md` — production-readiness gap analysis with prioritized remediation tasks, acceptance criteria and effort estimates.
- `docs/development/interfaces_roadmap.md` — detailed multi-interface roadmap (CLI, REST API, Admin UI, SDKs, Webhooks, Embeddables) aligned to sprints with API contracts and estimates.

## Roadmap Summary (preserved)

This concise summary preserves the prioritized roadmap, top acceptance criteria, key risks, and an actionable Sprint 1 checklist for quick onboarding and decision-making.

Top priorities
- Secure, auditable foundations: Constitution service, Policy Engine, Identity + Settings (Sprint 1).
- Observability & benchmarking: Prometheus/Grafana dashboards, benchmark harness (Sprint 2).
- Orchestration & capsule storage: MAO prototype and `task-capsule-repo` (Sprint 3).
- Marketplace & billing: capsule publish/review flow and billing event emission (Sprint 6).
- Ops & scaling: dashboard, traces, multi-region failover (Sprints 3–9).

High-level acceptance criteria
- Constitution endpoint returns a signed constitution hash and serves cached value.
- Policy evaluator returns {score, verdict} within expected latency bounds (example: <50ms for simple rules).
- SLM consumer accepts and logs jobs from an async queue.
- Marketplace publish flow stores attestation hashes and MAO can import approved capsules.
- Billing events include tenant id, adapter id, time window, and estimated token usage; events persist to analytics.

Top risks and mitigations
- Environment mismatches (python vs python3): standardize dev scripts to use `python3 -m venv .venv` and provide `dev/README.md` with explicit commands.
- Missing infra for integration tests (Redis/Postgres/Kafka): provide lightweight docker-compose dev overlays and in-memory fallbacks for tests.
- Frontend build errors until deps installed: keep `apps/admin-console/package.json` updated and add a `dev` run guide for Storybook and Vite.
- Billing contract mismatch between client wrappers, model-proxy and analytics: define a small JSON schema for `billing.events` early and add contract tests.

Sprint 1 quick checklist (actionable)
1. Implement `constitution-service` (FastAPI): GET `/v1/constitution` returns deterministic SHA256 hash of canonical constitution + dev signature; cache in Redis if available.
2. Implement `policy-engine` (FastAPI): POST `/v1/evaluate` that accepts an action and returns `{score, verdict}`; include unit tests and a simple timing assertion.
3. Implement `slm-service` skeleton: async in-memory queue, POST `/v1/jobs` to enqueue, worker that logs placeholder results; health endpoint.
4. Implement `settings-service` CRUD (dev persistence via SQLite): model profiles and a simple OpenAPI contract test.
5. Add docs: `docs/development/run_local_dev.md` with steps to start Redis (docker), create venvs, run each service, and a smoke-test script that exercises the endpoints.

Developer ergonomics (small wins)
- Add per-service `run_dev.sh` which creates a `.venv`, installs dependencies, and runs uvicorn on a predefined port.
- Use consistent `python3` in scripts and add a `.nvmrc` + Node install note for frontend developers.
- Add a single `dev/README.md` that lists the minimal steps to bring up Redis, start services and run smoke tests.

If you need, I can implement the minimal `constitution-service` and the `dev/README.md` now (creates service folder, FastAPI app, tests, and run script). Mark this file updated to record the changes.

Add these to your reading list when planning hardening, security, and launch sprints.

``` 
