# SomaGent UIX — Revolutionary, Realistic, and Truthful

Generated: 2025-09-24

Purpose
-------
This document consolidates the best UI/UX patterns across modern open-source agent platforms (AutoGPT, CrewAI, LibreChat, AnythingLLM, Agent Zero, AgentGPT and others) and fuses them with the SomaGent architecture and requirements to propose a single, pragmatic, and forward-looking UIX for SomaGent. The goal: make powerful multi-agent orchestration approachable, auditable, and delightful — while remaining implementable by an engineering team and safe for production use.

Design Principles (truthful & pragmatic)
--------------------------------------
- Minimal cognitive load: put the complexity under the hood; present clear, task-oriented paths and templates for common outcomes.
- Provenance visible by default: provenance & request_hash are first-class UI artifacts (badges, drill-downs) not buried in logs.
- Progressive disclosure: simple chat-first UX for new users; expert panes (Ops, Terminal) for power users.
- Composability & Templates: every complex flow should be reusable as a Capsule/Template and installable from the Marketplace.
- Observable & Controllable: real-time monitors, token/cost estimation, and human-in-the-loop gates are built-in.
- Security-first: never expose provider credentials client-side; templates are sanitized; RBAC enforced in UI flows.
- Accessibility & Internationalization: WCAG AA baseline and i18n support from day one.

High-level Product Flows (user stories)
-------------------------------------
1. New user: "Create a Research Assistant" → pick a Research template from Marketplace → confirm token budget and tenant settings → kickoff → watch a simple chat timeline where an agent produces a report.
2. Power user: "Run a multi-step project" → open Crew Builder → assemble Roles/Goals and tools → start crew → watch Ops Dashboard, step-in at checkpoint, export artifacts.
3. Auditor/Operator: "Trace a result" → click provenance badge on a message → see request_hash, signatures, policy decisions, and the capsule trace (MAO nodes + tool events).

Core UI Surfaces and Components
-------------------------------
These will be implemented in `@somagent/uix` and consumed by `apps/admin-console` (and other UIs):

- Global Layout
  - Top nav: Tenant selector, Search, Notifications, User menu.
  - Left rail: Workspaces, Agents, Templates/Marketplace, Ops Dashboard, Settings.
  - Main canvas: page content; supports split panels (composer/timeline | inspector | terminal).

- ConversationWorkspace (primary product view)
  - Composer: markdown editor + slash-commands + persona selector + token estimate preview.
  - ConversationTimeline: virtualized message list with streaming partials, message controls (stop/re-run/fork), and provenance badges.
  - Inspector pane: message metadata, provenance trail, memory snippets used, trace link.

- AgentBuilder / Crew Builder
  - Simple mode: name, high-level goal, persona (pick from marketplace), budget, tools.
  - Advanced mode: Role definitions (role name, responsibilities, tool bindings), delegation rules, review gates.
  - Preview and estimate modal: shows token/cost estimate, approximate wall clock time, and sample output.

- Templates / Marketplace
  - Template card (MarketplaceCard) with metadata: cost estimate, required tools, persona dependencies, compliance tags, install button.
  - One-click import: installs a capsule into tenant library (sanitizes secrets) and optionally instantiates a test run.

- Ops Dashboard
  - Running crews summary (counts, cost/use, SLOs), visual timeline of major events, error list.
  - Crew detail: DAG visualization, per-node logs, ability to pause/resume/step-in/assign-to-user.

- AgentTree & Trace Viewer
  - Collapsible agent tree showing active subagents and their status.
  - Trace viewer shows Temporal/MAO nodes, tool calls, and links to raw events (Kafka+SomaBrain anchors).

- Developer Terminal / Instrumentation Pane
  - Live logs, SSE/WebSocket raw stream dump, ability to replay a request via `request_hash`.

- Marketplace Onboarding & Docs Chat
  - Embedded RAG-powered doc chat for templates and guided onboarding.

UX Patterns and Interaction Details (concrete)
-------------------------------------------

1) Streaming-first timeline
  - Token streaming is first-class: we render incremental tokens as they arrive and progressively compute token counts.
  - UI shows a live token meter and an estimated cost badge. The stop button cancels runtime and triggers a billing-close event.

2) Provenance badge & drilldown
  - Every message has a provenance badge (compact): request_hash, source (agent/capsule), tenant, timestamp.
  - Click → open Inspector with signed metadata, policy decisions, server-observed token accounting, and link to trace node(s).

3) Templates as primary UX accelerator
  - Marketplace templates have a 2-click install: (1) preview modal with cost/permissions; (2) install into workspace.
  - Template installs can be 'seeded' into a workspace with optional test-run that creates a demo conversation.

4) Crew Builder flow
  - Use a guided wizard: define Goal, add Roles (human-friendly names), bind tools (checkbox UI), and add review gates.
  - Show JSON/YAML preview toggle for power users with schema validation errors inline.

5) Ops-first observability
  - Ops Dashboard exposes quick controls: pause a crew, reduce budget, escalate, or snapshot state.
  - Timeline and DAG visualizations use color-coded node states and inline cost burn rates.

6) Human-in-the-loop & Step-In UX
  - At defined review gates, the UI surfaces a modal allowing an operator to review outputs, edit prompts or reassign roles, and approve to continue.

7) Cost transparency and safety
  - Before kickoff show an itemized estimate (prompt tokens, expected completion tokens, tool costs). Allow hard budget caps that auto-pause runs.

Data Contracts & Events (concrete mappings)
-----------------------------------------
These are additions/enrichments to the existing API contracts in `SomaGent_UIX_Final.md`.

- UI → Gateway headers
  - `Authorization: Bearer <OIDC token>`
  - `X-Tenant-ID: <tenant>`
  - `X-UI-Client: somagent-admin/1.0`

- Streaming events (SSE/WebSocket): add `provenance` envelope
  - message.start { conversation_id, message_id, sender, timestamp, provenance }
  - token { message_id, seq, text, delta_tokens }
  - message.end { message_id, tokens: { prompt, completion, total }, cost, provenance }

- Ops events
  - crew.created { crew_id, template_id?, owner, initial_budget }
  - crew.node.update { crew_id, node_id, state, reason }
  - crew.paused/resumed/terminated

- Trace / Audit links
  - All UI actions that mutate state should return an `audit_link` (URL or event id) to quickly inspect the backing Kafka/event store and named resources in SomaBrain.

Accessibility, Localization & Theming
------------------------------------
- Provide theme tokens mapped to CSS variables (seeded from `settings-service`) so tenants can brand quickly.
- Ensure keyboard-first composer and timeline navigation, aria labels for streaming updates, and color contrast meeting WCAG AA.
- Expose localization strings and a translation guide for templates/marketplace content.

Acceptance Criteria (measurable)
--------------------------------
MVP acceptance criteria (must pass):
1. Installable template flow: user can install a template from Marketplace and instantiate a demo run in the tenant workspace.
2. Streaming timeline: timeline shows streaming tokens from `model-proxy` and displays live token counts and cost estimate.
3. Provenance drilldown: clicking a provenance badge opens an Inspector showing request_hash, server-observed token counts, and a trace link.
4. Crew Builder (simple): user can create a crew with Roles and a Goal, save it as a capsule, and instantiate one run.
5. Ops Dashboard (basic): lists running crews with their budgets and allows pausing a run.

Roadmap & Prioritization (realistic)
------------------------------------
MVP (0–6 weeks, low-risk)
- Templates folder + MarketplaceCard UI (install & preview)
- Streaming timeline wiring to `services/model-proxy` (SSE consumer component)
- Provenance badge + Inspector (static data from backend)

Velocity v1 (6–12 weeks)
- Crew Builder (simple wizard) and template-to-capsule conversion
- Ops Dashboard MVP with pause/resume and crew list
- Token/cost estimation service hook and estimate modal

Velocity v2 (12–24 weeks)
- Advanced Crew Builder (role delegation rules, review gates)
- Trace viewer and Temporal/MAO DAG visualization
- Replay/fork UI and terminal replay via `request_hash`

Longer-term (24+ weeks)
- Full marketplace lifecycle (install, rate, vet, compliance badges)
- In-UI persona tuning and regression dashboards
- Deep integrations: VSCode devspaces, design tools, CI/CD templates

Prototype plan (concrete small wins)
----------------------------------
Prototype A (Templates import + Marketplace flow) — Quick win (2–4 days)
- Create `docs/templates/` with 3 seeded starter capsules (research, summary, extractor).
- Add UI hook in `apps/admin-console` MarketplaceCard: preview modal + install (writes seed JSON to `tenant_seeded_templates/`).

Prototype B (Crew Builder minimal) — Medium (1–2 weeks)
- Simple wizard UI that posts a capsule to `POST /v1/agents` or `/v1/capsules/import`.

Prototype C (Ops Dashboard skeleton) — Medium (1–2 weeks)
- List crews (GET stubbed `/v1/orchestrator/crews`) and pause/resume actions.

Implementation notes & mapping to repo
------------------------------------
- `apps/admin-console/src/pages/agent-embed.tsx` — reuse as a simple host for embed demos and Marketplace preview flows.
- `libs/uix/MessageTimeline.tsx` — extend to render token streams and provenance badges.
- `services/model-proxy/app.py` — used for streaming testing; ensure SSE payloads include `provenance` envelope.
- `docs/development/CREWAI_Analysis.md`, `docs/development/LIBRECHATResearch.md` — use templates and crew ideas as seed content.

Quality gates and tests
-----------------------
- Unit tests for `MessageTimeline` storybook stories (happy path + partial stream + error stop).
- Contract tests for `/v1/models/invoke` streaming format (SSE shape) and `/v1/billing/events` emission.
- Playwright e2e: install template, instantiate demo run, verify timeline shows streaming tokens and provenance inspector opens.

Risks, trade-offs & mitigations
------------------------------
- Cost surprises: Mitigate with pre-kickoff estimates and hard budget caps. Surface historical averages per template.
- UX complexity from multi-agent flows: Mitigate with templates and a simple-first, advanced-later pattern.
- Security of templates: Templates stripped of secrets and validated by a policy engine on import.

Closing: the revolution is compositional
--------------------------------------
The radical change here is not introducing a flashy new widget; it's combining three truths:
1) Agents are useful when they are repeatable (Capsules/Templates). 2) People will adopt if the UI makes costs, provenance, and governance obvious. 3) Operations must be able to observe and control runs in real-time.

This UIX makes those truths center-stage: templates and crews reduce cognitive load, provenance is always visible (so trust is immediate), and Ops can safely scale usage with clear budgets and review gates. It's revolutionary because it treats agents as production workflows from day one — but realistic because it builds on small, testable prototypes that map directly to the existing SomaGent architecture.

---

End of document.
