# SomaGent UIX Final Interface Specification

This document consolidates the UI/Experience (UIX) interface spec for SomaGent. It synthesizes the best UX elements from Agent Zero, LibreChat, and AnythingLLM and defines the APIs, components, data contracts, and acceptance criteria for a production-ready, interface-agnostic SomaGent UI.

Generated: 2025-09-24

---

## Goals
- Interface-agnostic: any UI (web, mobile, embed, external widget) must be able to plug into SomaGent backends with minimal changes.
- Provenance-first: every user-visible artifact (message, memory snippet, tool-call) includes provenance metadata and deterministic request_hash for audit, deduplication, and billing.
- Multi-agent and workspace aware: support agent orchestration (subagents), workspace isolation, and document containerization.
- Secure: no provider credentials in the browser, tenant isolation, RBAC, and signed billing events.
- Accessible and themeable: WCAG compliance, tenant design tokens, and localization support.

### CrewAI-inspired extensions
- Multi-agent crew builder: surface a lightweight "crew" creation flow where users define Roles, Goals, and task delegation rules (mirrors CrewAI "Create Your Crew").
- Templates and playbooks: support templated crews and task templates that can be kicked off with one command from the UI.
- Live monitoring and step-ins: provide real-time task progress, per-agent logs, and ability for a human to "step in" or reassign goals mid-run.
- Agent orchestration dashboard: an operations view showing active crews, resource usage, and ability to snapshot/clone a running crew.
- Examples and onboarding: include guided templates, example repos, and an in-UI "chat with docs" helper for quick ramp-up.

---

## Core UI Components (library: `@somagent/uix`)
- atoms/
  - Button, Icon, Badge, Input, Select
- molecules/
  - MessageBubble (with streaming partials), Composer (markdown + slash commands), NotificationToast
- organisms/
  - ConversationTimeline (virtualized), MarketplaceCard, WorkspacePanel, AgentTree
- pages/
  - AdminDashboard, ConversationWorkspace, AgentBuilder, NotificationsTray

Each component must include Storybook stories and accessibility notes.

---

## API & Event Contracts (summary)
### Authentication
- All APIs require `Authorization: Bearer <OIDC token>` and `X-Tenant-ID` header when applicable.

### Streaming Conversation (WebSocket/SSE)
- Events:
  - `message.start` { conversation_id, message_id, sender, timestamp, metadata }
  - `token` { message_id, seq, text }
  - `message.end` { message_id, tokens: { prompt, completion, total }, cost }
  - `tool.call` { tool_name, args, call_id }
  - `tool.result` { call_id, status, payload }
  - `provenance.link` { message_id, memory_id }

### Model Invocation
- POST `/v1/models/invoke`
  - Body: { tenant_id, user_id, conversation_id, model: { provider, name }, prompt, options }
  - Response: streamed events (SSE or WebSocket)

### Memory Gateway
- POST `/v1/memory/search` -> returns [{ id, score, text, metadata:{provenance, document_id, workspace_id} }]
- POST `/v1/memory/ingest` -> { document_id, chunk_ids }

### Agents
- POST `/v1/agents/{agent_id}/spawn` -> creates subagent/tracing
- GET `/v1/agents/{agent_id}/trace` -> returns DAG of nodes

### Billing
- POST `/v1/billing/events` -> accept billing events with `request_hash` and `provenance`

---

## Data Models (high-level)
- Message: { id, conversation_id, sender, text, tokens, timestamp, provenance }
- Provenance: { request_hash, signature?, client, client_version, tenant_id, user_id, timestamp }
- MemorySnippet: { id, document_id, workspace_id, text, offset, provenance }
- AgentTraceNode: { node_id, agent_id, action, tool_calls[], outputs[], provenance }

---

## UX Patterns & Behavior
- Streaming UI: incremental rendering with partial tokens, pause/resume, stop button, and ability to re-run or fork a message.
- Multi-agent tree: collapsible agent tree with trace inspection and ability to promote subagents into main conversation.
- RAG integration: in-line snippet cards with provenance link and "use in reply" quick action.
- Composer: slash-commands for tools, persona toggles, token estimate preview.
- Marketplace: curated persona cards with install flow and permission modal.
- Terminal pane: developer mode for advanced users to run instruments and spawn agents.

---

## Security & Operational Requirements
- All provider calls proxied via `model-proxy` (no browser -> provider calls).
- Billing events signed server-side where possible; server validates events against observed token usage.
- Tenant isolation enforced at API and storage layers.
- CSP and postMessage origin checks for embeds.

---

## Acceptance Criteria (top-level)
1. An embedded UI (iframe) can stream model responses via `model-proxy` and show provenance badges.
2. Memory snippets displayed have clickable provenance links into SomaBrain memory viewer.
3. Billing events are emitted for each completed model invocation and written to the billing ledger.
4. Agent spawn/trace is visible and inspectable in the UI.
5. Theme tokens from `settings-service` update UI variables live.

---

## Recommended Sprint Next Steps
1. Spike: create iframe demo page `apps/admin-console/src/pages/agent-embed.tsx` + simple CSS variable shim.
2. Scaffold `services/model-proxy` streaming stub + billing emitter.
3. Create `libs/uix/` scaffold with `MessageTimeline` + Storybook.

---

## Files created/recommended
- `docs/development/SomaGent_UIX_Final.md` (this file)
- `libs/uix/` (component library)
- `services/model-proxy/` (adapter)
- `apps/admin-console/src/pages/agent-embed.tsx` (embed demo)

---

End of spec.
