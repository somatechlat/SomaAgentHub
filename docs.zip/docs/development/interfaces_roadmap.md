```markdown
# Interfaces Roadmap & Implementation Plan — SomaGent

This document defines the multi-interface strategy (CLI, REST API, Admin UI, SDKs, Webhooks, Embeddables) and maps work to sprints, API contracts, auth models, acceptance criteria, and estimates. It aligns with `Sprint_Plans_Extended.md` and the implementation roadmap.

## Goals
- Provide consistent, discoverable interfaces for developers, operators, and end-users.
- Ensure all interfaces produce auditable events and carry provenance metadata.
- Prioritize REST API & SDKs first (backend-first), then UX/CLI and embeddables.

## Interface types
1. REST API (Primary)
2. SDKs (Python, TypeScript)
3. Admin UI (React, Vite)
4. CLI (devops, power users)
5. Webhooks & Event Sinks
6. Embeddable UI / Iframe (Capsule authoring, read-only)

---

## 1) REST API — contract highlights

Design principles
- JSON-first contracts, OpenAPI/Swagger for discoverability.
- All calls must accept/expose `X-Tenant-ID` and optional `X-Provenance` headers.
- API gateway (Memory Gateway & main Gateway) adds auth context and signs important calls.

Core endpoints (examples)
- POST /v1/memory/remember — body: { text, tags?, metadata? } -> response: { id, hash, provenance }
- POST /v1/memory/recall — body: { query, filters?, top_k? } -> response: { items: [{id, text, score, provenance}] }
- POST /v1/memory/link — body: { source_id, target_id, type, metadata? }
- POST /v1/sessions/start — body: { capsule_id, tenant_id, persona, inputs } -> response: { session_id, status }
- POST /v1/tools/{tool_id}/invoke — body: { params, context } -> response: { result, billing_estimate, provenance }

Auth model
- Service-to-service: mTLS or scoped service tokens.
- User access: JWT with OIDC or internal auth; capability claims (scopes) for actions like `memory:write`, `memory:read`, `tool:invoke`.

Acceptance criteria
- OpenAPI: automated spec generation and validation in CI.
- All endpoints return provenance and telemetry headers for tracing.

Estimated effort (API layer)
- Design + OpenAPI + basic implementation: 3–5 days
- CI validation + test harness: 2 days

---

## 2) SDKs — Python & TypeScript

Purpose
- Provide idiomatic clients that wrap REST contracts, inject tenant and provenance, handle retries and sign writes (if needed).

Features
- `remember(text, tags, metadata)` — returns canonical id and hash
- `recall(query, filters)` — returns ranked items with provenance
- Async support for Python; fetch helpers and context managers for tenant scope

Acceptance criteria
- SDK publishes simple examples in `examples/` and is usable in local dev within 30 minutes.

Estimated effort
- Python SDK (initial): 2–3 days
- TypeScript SDK (initial): 2–3 days

---

## 3) Admin UI / UX

Scope
- Settings pages, capsule gallery, persona builder, monitoring dashboards (Agent One Sight), approvals UI, and embedded capsule preview.

Key flows
- Capsule submission & review, persona editing, tenant settings, and billing exports.

Acceptance criteria
- Admin UI can authenticate (OIDC or local dev flow), list capsules, view capsule metadata (including provenance), and invoke a dry-run of a capsule.

Estimated effort
- Core pages + storybook components: 3–4 weeks for MVP

---

## 4) CLI

Purpose
- Power-user automation and scripting: create tenants, install capsules, run a local dry-run, export logs.

Commands (examples)
- `soma tenant create --name ...`
- `soma capsule install --file capsule.yaml --tenant <id>`
- `soma session run --capsule-id ... --input-file ...`

Acceptance criteria
- CLI authenticates against the gateway, provides verbose logging, and emits machine-friendly JSON output for automation.

Estimated effort
- Prototype CLI (Python Click or TS OClif): 2–3 days

---

## 5) Webhooks & Event Sinks

Purpose
- Allow external systems (billing, notification, analytics) to subscribe to events: memory.write, tool.invoke, billing.event, capsule.run.complete.

Design
- Event broker (Kafka) publishes events; gateway exposes `POST /v1/webhooks` for registering HTTP sinks and delivers fan-out via an internal worker.

Acceptance criteria
- Webhook delivery retries with exponential backoff; webhooks record last delivery status and expose logs in Admin UI.

Estimated effort
- Webhooks core: 3–5 days

---

## 6) Embeddable / Iframe (Capsule Preview)

Purpose
- Allow embedding a read-only capsule builder/preview into external admin panels or partner apps.

Design
- Single-sign-on using signed short-lived token; CSP and sandboxed iframe; limited API surface for preview-only calls.

Acceptance criteria
- Admin can embed capsule view in iframe with CSP policies set and access control enforced.

Estimated effort
- Embeddable component + auth: 1–2 weeks

---

## Roadmap by sprint (focused tasks)

- Sprint 0: REST API core (memory endpoints), OpenAPI, skeleton Python SDK, minimal Admin UI skeleton.
- Sprint 1: Expand APIs for sessions, tools; implement SDK retry/signing; prototype CLI commands and basic webhook sink.
- Sprint 2: Admin UI pages for settings and capsule gallery; OpenAPI-driven UI components; add SDKs to examples.
- Sprint 3: Embeddable preview, webhooks in production mode, richer CLI features, Admin approvals UI.
- Sprint 4: Harden auth (OIDC integration), tenant scoping UI, billing exports; add upgrade to SDKs for token rotation.

## Cross-cutting requirements
- All interfaces must propagate provenance (tool/capsule/persona/run_id) and include tenant headers.
- OpenTelemetry traces must be propagated and retrievable for any interface action.
- API contracts should be validated in CI; SDKs must include integration smoke tests that exercise real somabrain docker image.

## Next steps (actionable)
1. Add OpenAPI generation to core services and publish a central `openapi.yaml` in `docs/` during CI.
2. Start Python SDK in `libs/python/somagent_client` with memory wrapper functions and quick examples.
3. Add CLI prototype in `tools/cli/` that uses the TypeScript SDK or Python SDK.

``` 
