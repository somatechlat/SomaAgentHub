## Local development and no in-repo stubs

This repository does not include in-repo development stubs, mocks, or
bypasses that are usable in production. For local development run real
backend services or provide adapter implementations that integrate with the
service interfaces. Do not rely on in-repo simulated implementations.

Run local development environment (canonical)
===========================================

Purpose
-------
This document collects canonical developer steps to boot the Sprint 1 services locally, run a quick smoke test, and validate the minimal SLM/Policy/Constitution contracts used by early integration tests.

Prerequisites
-------------
- macOS or Linux with `python3` (>=3.10) and `curl` installed.
- Recommended: `git`, `make` and `docker` (optional for Redis/Postgres when you need integration).

Service ports used in this guide
-------------------------------
- Constitution Service: http://127.0.0.1:51010 (GET /v1/constitution, /health)
- Policy Engine: http://127.0.0.1:51011 (POST /v1/evaluate, /health)
- SLM Service (demo): http://127.0.0.1:51012 (POST /v1/jobs, /v1/jobs/{id}, /v1/queue/stats, and SLM-compatible endpoints `/infer_sync`, `/embedding`, `/slm/generate`, `/slm/stream`)

All services expose Prometheus metrics at `/metrics` (e.g., `http://127.0.0.1:51010/metrics`). Use this to scrape metrics locally or query with `curl`.

Start services (recommended, one terminal per service)
---------------------------------------------------
Open three terminals (or run in tmux) and run the following in each service folder.

Constitution service
```bash
cd services/constitution-service
./run_dev.sh
# or use: ./.venv/bin/uvicorn constitution_service.app:app --host 127.0.0.1 --port 51010
```

Policy engine
```bash
cd services/policy-engine
./run_dev.sh
# or use: ./.venv/bin/uvicorn policy_engine.app:app --host 127.0.0.1 --port 51011
```

SLM service
```bash
cd services/slm-service
./run_dev.sh
# or use: ./.venv/bin/uvicorn slm_service.app:app --host 127.0.0.1 --port 51012
```

Running the smoke test
----------------------
Once services are running, from the repository root run the smoke test script:

```bash
chmod +x scripts/dev/smoke_test.sh
./scripts/dev/smoke_test.sh
```

What the smoke test does
------------------------
- Health-check all services
- Query `/v1/constitution` and validate the presence of `hash` and `signature`
- POST a sample action to `/v1/evaluate` and assert `score` and `verdict`
- Submit a capsule job to `/v1/jobs`, then fetch job status and call `/v1/queue/stats`
- Call the SLM-compatible endpoints: `/infer_sync`, `/embedding`, `/slm/generate`, `/slm/stream`

Notes & next steps
-------------------
- For integration testing, provide a `docker-compose.dev.yml` overlay that brings up Redis and Postgres; the current services use in-memory persistence for speed.
- For CI, call the same smoke-test script after launching services in background processes (or use pytest-based integration tests).

Using Redis for SLM queue (optional)
----------------------------------
You can start Redis locally via docker-compose (file `docker-compose.dev.yml` included). From the repo root:

```bash
docker-compose -f docker-compose.dev.yml up -d redis
```

Then start the `slm-service` with `REDIS_URL` pointed at the local Redis instance:

```bash
cd services/slm-service
export REDIS_URL=redis://127.0.0.1:6379/0
./run_dev.sh
```

When `REDIS_URL` is set and `redis.asyncio` is available, the `slm-service` will use Redis for job persistence and queueing instead of the in-memory queue.

Deployment modes (DEV_LIGHT | DEV_FULL | PROD | PROD_DEBUG)
---------------------------------------------------------
This project supports four deployment modes to match different workflows: quick development, full local integration, production, and a production-grade debug environment.

Mode summary
- DEV_LIGHT — Fast local iteration. Starts only the minimal containers required to develop the application and uses in-memory persistence by default. External services (Redis, Kafka, Postgres) are not started unless explicitly requested or detected on the host.
- DEV_FULL — Full local integration. Starts Redis, Kafka, Postgres (and optional MinIO, Prometheus/Grafana) with named volumes for persistence so you can run E2E tests locally.
- PROD — Production deployment targeting Kubernetes or managed platforms. Uses managed or cluster-level stateful services, PVs, backups, and HA configurations.
- PROD_DEBUG — Production-like cluster with debug sidecars, elevated tracing and log retention for troubleshooting.

How the modes are selected and used (developer tooling)
- The recommended entrypoint for local workflows is a wrapper script (planned: `scripts/dev/dev_up.sh`) which accepts a `MODE` variable and performs safe, idempotent environment setup:
	- `MODE=DEV_LIGHT ./scripts/dev/dev_up.sh`
	- `MODE=DEV_FULL ./scripts/dev/dev_up.sh`
	- `MODE=PROD ./scripts/dev/dev_up.sh` (for advanced users; will rely on Kubernetes manifests/Helm)
	- `MODE=PROD_DEBUG ./scripts/dev/dev_up.sh`

Key behaviors implemented by the wrapper
- Port safety and reuse: Before starting services the wrapper checks host ports (e.g., 6379) and, if a compatible service responds (Redis PING -> PONG), the wrapper will reuse it instead of creating a new container. If the host port is taken by a non-compatible process, the wrapper will select a free port and map the container there.
- Idempotent startup: Re-running the wrapper will reuse existing containers when healthy, pull images only when missing (or when `--pull` is requested) and create named volumes for persistence.
- Healthchecks & restart policies: DEV_FULL deploys services with healthchecks and `restart: unless-stopped`; PROD uses readiness/liveness checks in Kubernetes and persistent volumes.

Where to look for more details
- The `docker-compose.dev.yml` file contains the Compose definitions used for DEV_FULL flows. The wrapper will generate an override file or export `.env` values to wire selected ports and service reuse.
- `docs/development/run_local_dev.md` (this document) contains quick start steps and smoke-test instructions.

If you need the wrapper implemented now, open an issue or request "implement wrapper" and it will be added to the developer tooling with sensible defaults.

Using the idempotent dev launcher (DEV_FULL example)
--------------------------------------------------
The repository includes a small launcher script `scripts/dev/dev_up.sh` that implements safe, idempotent startup for DEV_LIGHT and DEV_FULL modes. Example:

```bash
# Start a full local stack (will reuse host Redis if it responds to PING, otherwise start container)
MODE=DEV_FULL ./scripts/dev/dev_up.sh

# Start a fast local stack (no Redis/Kafka/Postgres started)
MODE=DEV_LIGHT ./scripts/dev/dev_up.sh
```

The launcher will export environment variables the compose file reads (for example `REDIS_BIND_PORT`) and will print the final endpoints once the stack is healthy.

Docker builds and what changed
-------------------------------
We standardized on a single canonical Dockerfile at `infra/docker/docker-canonical.Dockerfile` and tightened build contexts to avoid accidentally including backups, `.git` metadata, `node_modules`, large datasets or local developer artifacts in images.

Important points for developers:
- Most services build from their service folder context (fast and small). Use `build.context: ./services/<service>` in compose if you change service locations.
- If a service lists editable local libs (e.g., `-e ../../libs/python/...`) the compose file will build from repo root and pass `SERVICE_SRC_REL` and `EXTRA_COPY` so the builder can install those local packages safely.
- `.dockerignore` at the repo root plus per-service `.dockerignore` files prevent accidental inclusion of developer artifacts in build contexts.

See `infra/docker/README.md` for full details, examples and recommended commands.
