```markdown
# Production-readiness gap analysis — SomaGent agent

Scope: the running SomaGent project (early-stage agent + scaffolds), SomaBrain as canonical memory, PipesHub integration, and the services scaffolds already created (constitution-service, policy-engine, slm-service). Focus areas: security, infra, observability, data governance, testing, performance, operations, and product acceptance.

## Summary judgement
- Current state: early PoC scaffolds exist, core architecture drafted, and a canonical memory (SomaBrain) selected. Good start for experimentation.
- Gap profile: missing production-grade security (auth, key management), governance (provenance & audit), infra hardening (HA, TLS, backups), observability, resilient messaging, and comprehensive testing/CI.
- Priority: fix security, tenancy, and auditability first; then infra/availability and observability; then testing/performance and operational runbooks.

---

## 1) Security & Identity (High priority)

### Gaps
- No enforced inter-service auth; `DISABLE_AUTH` used for dev in SomaBrain examples.
- No KMS/Vault integration for signing keys or secrets.
- No mutual TLS or service-to-service authentication patterns.
- No fine-grained scopes for tool/service tokens (remember vs recall vs link).
- Constitution signature verification not implemented.

### Remediation tasks
- Integrate HashiCorp Vault or cloud KMS and store service keys/secrets there.
- Enforce mTLS or token-based auth for all inter-service calls; configure Somabrain with auth enabled for prod.
- Implement scoped service tokens and IAM-like enforcement at Memory Gateway.
- Add signature verification flow in `constitution-service` (verify signatures using public keys from Vault/KMS).

### Acceptance criteria
- All services use service tokens or mTLS; no plaintext secrets in repos; keystore referenced by env variables.
- Memory Gateway rejects unsigned or invalidly signed writes.

### Estimated effort
- Vault/KMS integration + token issuance: 2–4 days
- mTLS/tokenization + runtime config: 2–3 days
- Signature verification implementation: 1–2 days

---

## 2) Tenancy & Data Isolation (High priority)

### Gaps
- Multiple services must send `X-Tenant-ID`; risk of missing/incorrect tenant headers.
- No per-tenant quotas, rate-limits, or data partitioning in infra.

### Remediation
- Memory Gateway must enforce `X-Tenant-ID` header presence and validate against tenant registry or auth context.
- Add per-tenant rate limiting and quotas in gateway (e.g., via Redis token bucket).

### Acceptance criteria
- Requests without tenant header are rejected.
- Per-tenant metrics and limits are visible in Prometheus.

### Estimated effort
- Header enforcement + simple tenant registry: 1 day
- Rate-limiting + dashboards: 2 days

---

## 3) Provenance, Audit & Billing (High priority)

### Gaps
- No enforced provenance metadata for every memory write.
- No audit log pipeline; reads/writes are not tied to billing metrics.
- No deterministic IDs or replay protection (idempotency).

### Remediation
- Define a simple provenance schema and require Memory Gateway to attach it to all /remember and /link writes.
- Emit audit events to a streaming sink (Kafka) or append-only audit store.
- Compute deterministic hashes of writes and store as idempotent keys.

### Acceptance criteria
- Every persisted memory record includes provenance fields {tool, capsule_id, persona, run_id, signature, signed_at}.
- Audit events are visible in a test analytics pipeline (e.g., local Kafka consumer or file).

### Estimated effort
- Schema + gateway enforcement + tests: 2–3 days
- Audit pipeline setup (Kafka or file sink) + dashboards: 2–4 days

---

## 4) Observability & Monitoring (High priority)

### Gaps
- Limited metrics across services; need end-to-end traces for requests.
- No centralized logs or distributed tracing yet (Jaeger/OTel missing).

### Remediation
- Add Prometheus metrics per service and enable `/metrics`. Instrument gateway, policy-engine, and SLM service.
- Add OpenTelemetry traces (or jaeger) with context propagation for agent runs (agent_run_id).
- Centralize logs to a logging backend (Loki/ELK).

### Acceptance criteria
- Per-tenant remember/recall/link counters exist.
- Traces show end-to-end path for a sample agent run.

### Estimated effort
- Metrics + basic dashboards: 2 days
- Tracing + propagation across services: 2–3 days
- Centralized logs deployment: 2–3 days

---

## 5) Resilience, scaling & infra (High priority)

### Gaps
- No HA/deployment guide for services (stateless vs stateful).
- No backup for SomaBrain state (if local mode used).
- No circuit-breakers, retries, or fallback modes in services.

### Remediation
- Create Helm charts or docker-compose production variants; define resource requests/limits.
- Add backup/restore playbook for SomaBrain persistent state.
- Implement retry/backoff and circuit breaker patterns in Memory Gateway and clients.

### Acceptance criteria
- Services deployable with replicas and resource limits.
- Backups can be restored in a smoke test.

### Estimated effort
- Charts + resource tuning: 2–4 days
- Backup/restore playbook: 1–2 days
- Client resiliency: 1–2 days

---

## 6) Testing, CI/CD & Verification (High priority)

### Gaps
- No unit tests for new scaffolds (constitution, policy, slm).
- No integration tests that spin up somabrain and validate remember/recall end-to-end.
- No CI pipelines for linting, security scans, and tests.

### Remediation
- Add unit tests (pytest) for service logic. Add small integration tests that bring up soma docker image.
- Add GitHub Actions or CI pipeline: lint, typecheck, unit tests, integration smoke.

### Acceptance criteria
- PRs must pass lint + unit tests.
- Integration test for memory-gateway -> SomaBrain run in CI (can use docker services).

### Estimated effort
- Unit tests + coverage: 2–3 days
- CI pipeline: 2–3 days

---

## 7) Data privacy & compliance (Medium priority)

### Gaps
- No PII detection/redaction pipeline.
- No retention policies or data deletion workflow (GDPR/DSR).

### Remediation
- Add a classification step in Memory Gateway to tag PII and enforce redaction rules.
- Implement retention and deletion endpoints and processes.

### Acceptance criteria
- Sensitive data flagged in a test corpus and redacted on retrieval per policy.

### Estimated effort
- PII detection integration: 2–3 days
- Retention policy tooling: 2 days

---

## 8) Performance & Cost control (Medium priority)

### Gaps
- No cost estimates per memory/recall and no quotas enforced.
- No benchmark tests to understand latency and throughput.

### Remediation
- Add per-request cost estimation (tokens, compute) into audit events.
- Run load tests (k6 or locust) against somabrain and memory-gateway.

### Acceptance criteria
- Benchmarks show acceptable latency under expected load (define SLA).

### Estimated effort
- Instrumentation + cost tags: 1–2 days
- Load testing: 2–4 days

---

## 9) Policy & Governance (Medium priority)

### Gaps
- Policy engine is a stub; no enforced decision gate between agent actions and tool calls.
- No human-in-the-loop approvals for high-risk actions.

### Remediation
- Implement policy evaluation with enforced blocking/allow logic and logs.
- Add approval flow for destructive actions (delete, external publish).

### Acceptance criteria
- Policy engine blocks a disallowed action in test and logs reason.

### Estimated effort
- Policy implementation + tests: 2–4 days
- Approval UI/workflow: 2–3 days

---

## 10) Developer ergonomics & docs (Low priority)

### Gaps
- README and developer setup need step-by-step for running somabrain, gateway, and scaffold services locally.
- No SDK docs for `libs/python/somagent_somabrain`.

### Remediation
- Add quickstarts in `docs/development`, example scripts, and an API contract doc.

### Acceptance criteria
- New developer can run a local end-to-end remember/recall within 30 minutes using docs.

### Estimated effort
- Docs + examples: 1–2 days

---

## Prioritised short roadmap (first 6 weeks)
- Week 1 (security & tenancy): Vault/KMS basic integration; Memory Gateway MVP (proxy + provenance + tenant header enforcement); unit tests for gateway.
- Week 2 (observability + CI): Add Prometheus metrics and basic dashboards; GitHub Actions: lint, tests, integration smoke.
- Week 3 (resilience + audit): Retries, circuit-breaker, idempotency keys; emit audit events to file/Kafka.
- Week 4 (policy + signing): Signature verification in constitution-service and signing in gateway (HMAC -> KMS).
- Week 5 (scaling & backups): Helm/compose production variants and backup playbook for SomaBrain.
- Week 6 (performance + compliance): Load tests + PII tagging for memory writes.

## Immediate next steps
1. Create Memory Gateway MVP scaffold `services/memory-gateway/` (FastAPI) with remember/link/recall proxy and provenance injection.
2. Add a HMAC signing helper and small unit tests.
3. Add an integration smoke test that runs a somabrain docker image and verifies remember->recall via gateway.

``` 
