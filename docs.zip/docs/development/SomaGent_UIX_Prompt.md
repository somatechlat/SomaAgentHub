SomaGent UIX Canonical Prompt
=============================

This file contains the canonical, exhaustive UIX prompt for the SomaGent interface generator. Use this as the single source-of-truth for generating React components, Storybook stories, and UI pages for the SomaGent Admin Console and shared UI library.

---

Copy the complete prompt below into your interface generator. It contains colors, tokens, component behavior, data contracts, accessibility requirements, animations, and acceptance criteria.

<START_PROMPT>

[Insert the full SomaGent UIX Canonical Prompt content here exactly as provided in the project UIX prompt delivered to stakeholders.]

<END_PROMPT>

Developer notes:
- This file is a reference and should be kept in sync with `docs/development/SomaGent_UIX_Revolution.md`.
- When updating the prompt, also update `docs/development/SomaGent_UIX_Revolution.md` acceptance criteria and prototype mapping.
