# CHANGELOG

All notable changes to this repository are documented here. Entries are
ordered newest first. This file is the canonical, human-readable record of
runtime and configuration changes made to production code.

## 2025-09-25 — Safe-defaults & no-stubs policy

Applied multiple changes to enforce a "no stubs in production" rule and to
make development stubs opt-in only. These changes were applied during a
maintenance session and include:

- `services/slm-service`: removed default `stub` provider and require an
  explicit provider configuration. The in-repo `StubProvider` is only
  registered when `SOMAGENT_ALLOW_DEV_STUBS=true`.
- `services/slm-service/app/core/providers.py`: improved error messaging for
  unknown providers and guarded registration of dev-only providers.
- `scripts/dev/check_no_stubs.sh`: added a simple grep-based lint script to
  detect occurrences of stub/simulate/fake/bypass/monkeypatch patterns in
  source directories. Intended for local checks and CI.
- `services/orchestrator`: `/v1/sessions/start` returns HTTP 501 unless
  `SOMAGENT_ALLOW_DEV_STUBS=true` is set — prevents accidental use of stub
  endpoints in production.
- `services/model-proxy`: requires explicit dev opt-in for stub behavior.
- `services/gateway-api`: moderation bypass now requires an explicit
  environment flag `SOMAGENT_ALLOW_MODERATION_BYPASS=true` to be honored.
- `.github/workflows/no-stubs.yml`: CI workflow added to run the no-stubs
  check on PRs and pushes to `main`.

Rationale: ensure production deployments never silently rely on in-repo
stubs, reduce accidental bypass of safety logic, and provide auditable
records in this changelog.

If you need a machine-readable audit of changes, we can add a small script
to append structured entries to this file automatically as part of patch
application.
